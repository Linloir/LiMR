# Consumer contract

## Choose by scenario

| Scenario | Recommended entry |
| --- | --- |
| Ordinary complete text and full reading UI | Reader |
| Large complete File/Blob/bytes/string with progress | AsyncReader + host Worker; read loading.md |
| Growing chat answer | Markdown/Reader with accumulated source and streaming, finalized with false |
| Static excerpt | Markdown with interactive=false |
| Custom layout/editor preview | One DocumentProvider and one primary Markdown; host scrollRoot and persistence |

Reader/Markdown source does not automatically move parsing to a Worker. Document windows reduce mounted body DOM; adaptive tables plan individual tables; code folding changes visible height. None makes source/AST storage independent of the complete input size.

## Minimal integration

```tsx
import { Reader, chinese } from '@linloir/limr';
import '@linloir/limr/styles.css';
import '@linloir/limr/math.css';

export function Article({ source }: { source: string }) {
  return <Reader source={source} locale={chinese} theme="auto" />;
}
```

React/React DOM 18.3 or 19, Node 20+, ESM. Choose styles.css or styles/base.css; the latter avoids browser requests for Maple but leaves fonts in the installed package. math.css is separate. CSS themes are imported separately and selected with appearance; that scope reaches portals.

Markdown is body-only, with no automatic toolbar. A composed DocumentProvider contains one primary <Markdown /> plus TableOfContents, AnnotationSidebar or AnnotationOverlay, and SelectionToolbar. A Markdown with source creates another document. Synchronized body/sidebar share one scroll container and unscaled coordinates; the host/grid supplies sidebar height. Use sync="none" for a separately scrolling annotation list.

For complete-file loading, worker setup, host-owned progress, cancellation, reading windows, print preparation and image preview, read [loading.md](loading.md). These APIs are separate from append streaming.

## Code controls (1.3.10)

Use `parameters={{ codeBlock: { autoCollapse: true, collapseAfterLines: 20, collapsedLines: 8, maxExpandedLines: false, wrap: false, lineNumbers: false } }}` on Reader, AsyncReader, Markdown or DocumentProvider. The defaults above make blocks exceeding 20 source lines or wrapped visual rows foldable, initially showing 8 rows. autoCollapse=false changes the initial view but preserves manual folding. The header orders wrap/copy/fold; short blocks omit fold. Copy includes all code, printed code expands, and unclosed streaming fences stay expanded until finalization unless manually folded.

Exported CodeBlockOptions is also accepted by codeHighlight(options). The host codeBlock object replaces the last plugin's whole object; missing fields use factory options, then built-in defaults. Per-block fold/wrap clicks override only their corresponding defaults; untouched blocks follow parameter changes without parsing again. Line numbers count original lines, share a number across wrapped continuations, and never enter native selection, source ranges or copied text. Prefer these parameters to CSS hiding or a renderer override.

Only manual choices enter a reader-local LRU capped at 256 modified blocks. Weak node identities avoid retaining source strings/trees; mounted state survives changes, and cached choices restore after virtual unmounts. An evicted block returns to defaults when remounted. Reader disposal/a new document key resets state; browser reloads do not persist it. Do not promise unlimited retention or source-level folding directives. Localization keys: expandCode, collapseCode, wrapCode, unwrapCode, plus foldedCode (`{hidden}` / `{total}` source-line counts, including a partly hidden wrapped line). The compact footer expands on click and shares the header label size, with animated hover/focus color and underline. Since 1.3.10, expanded code follows the page without an inner vertical scrollbar (maxExpandedLines=false); a positive number explicitly opts into a local scrolling viewport. Respect reduced motion. Verify long code together with document windowing, not in isolation.

## State and commands

Reader supports annotations/onAnnotationsChange. Supplying annotations makes it controlled; accept a change by storing the callback's complete array immutably and passing it back through annotations. Only a synchronous false return rejects a mutation. Other return values are ignored, including the number returned by array.push and Promises returned by async callbacks; an asynchronously resolved false does not undo a change. The callback type is (annotations: readonly Annotation[]) => void. Store data per article and supply a stable documentId. Changing Reader.key resets its internal state, not host state.

Annotation is { id, type, data?, range?, anchors?, source? }. source contains parsed module/ranges/rangeIds metadata; do not persist its offsets across revisions. Anchors are { range, documentId?, revision?, quote?, id? }. All offsets use the unmodified source's UTF-16 indices with an exclusive end. A quote relocates only when it matches uniquely; ambiguous or mismatched anchors can be omitted.

Selection exposes text, quality, settled, and raw/syntax/blocks (each with ranges and sourceText). Preserve all selected ranges and quote each original slice. Syntax absorbs adjacent standard delimiters, not unselected words or custom outer tags. Code can be selected partially; math/images/Mermaid and selection:atomic widgets select as a whole. Toolbar/native copying serializes each atom's complete original source, including $ delimiters, fences, or custom tags; surrounding ordinary text remains rendered text. A single atomic block anchors its toolbar below the block. Block-local copy buttons may deliberately copy only code, a URL, or another module-specific value.

useLiMR() exposes canEditSource, canEditAnnotation, editSource, addAnnotation, updateAnnotation, removeAnnotation, removeAnnotationsAt, editAnnotation, commitAnnotationEdit, cancelAnnotationEdit, activateAnnotation, clearSelection, invalidateAnnotation, and the engine. data updates replace the entire data object. addAnnotation normally adds a shared persistent highlight; highlight:false disables that. highlight:'hover' types skip automatic persistent highlights unless an explicit appearance is supplied. highlight annotations need no plugin and support background/underline/dotted/wavy plus hidden.

Create an editable annotation with a unique ID and addAnnotation(annotation, { edit: true, target? }). target defaults to 'annotations'; 'source' selects Markdown serialization. updateAnnotation(id, partial) returns whether persistence accepted the update. After saving successfully, commitAnnotationEdit(id?) marks the creation as saved and closes its editor; an omitted ID uses the current editor. editAnnotation(id) opens an existing record, and editAnnotation(null) closes and commits the current edit.

For explicit cancellation, restore the module's draft to its saved value before cancelAnnotationEdit(id?). A newly created annotation is removed, together with highlights generated by that creation that have no remaining use. Pre-existing highlights, highlights used by other annotations, and committed records survive. Cancelling an existing annotation closes editing without reverting data already persisted by updateAnnotation; the module owns draft restoration. A false result leaves the new annotation and editor in place, so restore the discarded draft and show the rejection.

An empty new draft that loses focus or leaves the active card should use the same cancellation path. Do not infer creation ownership from empty text or delete the highlight directly: the runtime records creations made with edit:true and applies the same ownership rules to source, controlled, and uncontrolled storage. Supplied external note modules retain nonempty drafts when dismissed; source note editors save accepted nonempty drafts when leaving. AnnotationEditor.onBlur fires only when focus leaves the entire editor, including its action buttons; the component does not save or cancel data itself.

Each editable card owns its single-annotation delete action, gated by canEditAnnotation(id). removeAnnotation(id) removes that record; the selection toolbar's removeAnnotationsAt(ranges) removes supported annotations bound to the exact selected fragments while retaining their other anchors. Clicking a marker provides its referenced range to the toolbar alongside the card; editing the active annotation suppresses those marker actions.

## Translation selection

`parameters.translationSelectionBoundary` is a boolean, defaulting to true. Set `<Reader source={source} parameters={{ translationSelectionBoundary: false }} />` to restore the previous native selection behavior and suppress boundary hints. It applies independently of translationMode and updates without reparsing. Omit it or use true to enable the boundary. Customize feedback through `locale.translationSelectionHint`; built-in English and Chinese locales supply the text. This is a browser-selection constraint only: preserve existing cross-boundary annotations and allow explicit addAnnotation/updateAnnotation ranges. It is not an annotation validation rule.

## Table layout (1.3.1)

Adaptive table layout is built into the default renderer and is independent of typography. `parameters={{ tableLayout: false }}` selects native browser layout without LiMR table measurement, layout observers, fixed columns, clipping or derived overflow previews. GFM, rich content, source selection and original annotations remain available. Omit the parameter for defaults, or use `{ maxColumnWidth, maxRowHeight, fontSize, cellPadding }` for numeric limits. `Reader`, `AsyncReader`, `Markdown` and `DocumentProvider` accept it.

`tableLayout: { algorithm }` accepts a synchronous `TableLayoutAlgorithm` over measured cells. Keep configuration/function references stable; replace them when closed-over state changes. Per-table `MarkdownTable.options` overrides host parameters, which override the last plugin supplying the parameter. The whole value is replaced, not merged: a host `{}` restores the built-in planner even if a plugin disabled or replaced it; omission inherits the plugin. Switching native/measured modes remounts table DOM and releases derived previews without reparsing source; focus and native selection need not survive the switch. See the plugin contract for a custom planner; use rendererOverrides only when measurement or DOM must also change.

## Streaming and resources

Pass the complete accumulated text to source and set streaming=false at completion. followOutput is opt-in and pauses after upward scrolling. Keep extensions/plugins stable. Appends and eligible finalization reuse stable prefixes; full-document transforms, changed definitions, and middle edits may require complete parsing. Growing code fences have a literal fast path.

New text and special blocks fade in without a background tint. streamEffect overrides animation keyframes/timing/className; false disables it. Extensions can provide streaming.effect and streaming.Loading. Incomplete code/math may render progressively while Mermaid waits for closure. Existing control state and selected text are retained; honor reduced motion in custom components.

typography defaults to standard; choose justify for browser justification or knuth-plass for TeX paragraph optimization with English Knuth–Liang hyphenation. The client adapter caches preparation, retains offscreen DOM, and protects active selections on width changes. knuthPlass configures tolerances, penalties, emergencyStretch, looseness, and hyphenate. Browser font shaping is not pixel-identical to TeX PDF; compare workloads using the repository performance report rather than promising universal timing parity.

SSR renders code text without client Shiki and a loading view for Mermaid; KP begins with standard layout and runs on the client. Await preloadMath() before synchronous SSR when complete formula HTML is needed. Framework client boundaries still apply to interactive components. Annotation loaders start when content is shown on the client; Preview only uses local data. Do not infer physical-device acceptance from Chromium mobile emulation.

## Importing a plugin

Read the actual installed package exports/peer dependencies. Import its factory, create a stable array, pass plugins, and import its CSS if required. Plugins add to defaults; extensions replaces them. Duplicate extension/tag/directive names throw. Parameter overrides belong in parameters and do not reparse source.

rendererOverrides replaces views without changing syntax: each rule has type, component, and optional when(node,{pending,incomplete,ancestors}). Last matching rules win; host rules override extension rules. This restricts where a renderer applies, not what third-party JavaScript can execute.

Missing plugin annotations retain data without markers, cards or type-specific interactions; reinstalling the type restores them. Playground switches install/uninstall complete modules, including renderers. Persist the complete annotations array: selection actions and removeAnnotationsAt preserve unsupported records, while explicit updateAnnotation/removeAnnotation can still manage them by ID.

Use docs shipped under node_modules/@linloir/limr/docs when available. Public source: https://github.com/Linloir/LiMR . Do not rely on internal src/dist imports.

The Playground always refreshes to its default document and standard typography. Edits are stored only through explicit Save, then opened manually from the saved-draft menu; locale preference persists separately. Reader itself supplies no persistence.

## Source editing

Provide `onSourceChange(next, { document, edits })` to opt into original Markdown edits; return false to decline, otherwise echo source and queue file saves in the host. This callback returns boolean | void; do not return the write Promise. `useLiMR()`/action contexts expose canEditSource(), canEditAnnotation(id), and editSource(edits,{revision?}). SourceEdit is {range,text}; validate against the same UTF-16 revision, with no overlaps. Streaming disables editing. Default sourceAnnotations parses paired `::%%limr%%{<#id}` / `::%%limr%%{>#id}` boundaries with complete `:::limr-annotation` definitions and supplies the generic editSourceAnnotations serializer. onSourceChange alone enables default task toggles and source highlight editing; the default highlightSelection action chooses source when enabled. Type modules own cards and dedicated actions: Playground inlineNotes supplies its type/action, and readingNotes supplies question cards. Existing annotations retain their origin on update; external annotations use onAnnotationsChange.

Paired boundaries can cross Markdown formatting, paragraphs, code and other named ranges. The serializer accepts complete source text boundaries, partial code text, and whole atomic nodes. It rejects split entities, escapes, UTF-16 surrogate pairs, CRLF pairs, active boundary tokens and hidden definition interiors. A boundary immediately following an odd run of backslashes is escaped and cannot be inserted by the writer. Close a trailing code, math or literal HTML block before appending a source annotation definition. Read fresh source coordinates after an accepted edit.
